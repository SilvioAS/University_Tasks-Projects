
package ServerSide;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.SocketAddress;
import java.util.concurrent.ConcurrentHashMap;
import javax.swing.*;
import se.mau.DA343A.VT25.projekt.LiveXYSeries;
import se.mau.DA343A.VT25.projekt.ServerGUI;
import se.mau.DA343A.VT25.projekt.net.ListeningSocketConnectionWorker;
import se.mau.DA343A.VT25.projekt.net.SecurityTokens;

public class ClientHandler implements ListeningSocketConnectionWorker {
    private ServerGUI gui;
    private ConcurrentHashMap<String, Double> applianceData;
    private String applianceName;
    private DataInput dataInput;
    private DataOutput dataOutput;
    private SocketAddress socketAddress;
    private LiveXYSeries<Double> totalConsumptionDiagram;
    private double clock = 0;
    private SecurityTokens tokens;
    private ConcurrentHashMap<String, LiveXYSeries<Double>> applianceSeriesMap;
    private Timer timer;

    public ClientHandler(ServerGUI gui, ConcurrentHashMap<String, Double> applianceData) {
        this.gui = gui;
        this.applianceData = applianceData;
        this.applianceSeriesMap = new ConcurrentHashMap<>();

        this.totalConsumptionDiagram = new LiveXYSeries<>("Total Consumption", 7);

        SwingUtilities.invokeLater(() -> {
            try {
                gui.addSeries(totalConsumptionDiagram);
            } catch (IllegalArgumentException e) {
                System.err.println("Series 'Total Consumption' already exists. Skipping addition.");
            }
        });

        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                diagramMetod();
            }
        });
        timer.start();
    }


    @Override
    public void newConnection(SocketAddress socketAddress, DataInput dataInput, DataOutput dataOutput) {
        try {
            this.socketAddress = socketAddress;
            this.dataInput = dataInput;
            this.dataOutput = dataOutput;

            SecurityTokens tokens = new SecurityTokens("DrDar");
            String newToken = dataInput.readUTF();

            if (!tokens.verifyToken(newToken)) {
                dataOutput.writeUTF("NACK");
                return;
            } else {
                dataOutput.writeUTF("ACK");
            }

            //SwingUtilities.invokeLater(() -> gui.addLogMessage("Client connected: " + socketAddress));

            while (true) {
                String message = dataInput.readUTF();
                processMessage(message);
            }
        } catch (IOException e) {
            SwingUtilities.invokeLater(() -> gui.addLogMessage("Client " + socketAddress + " disconnected."));
        } finally {
            cleanup();
        }
    }

    private void processMessage(String message) {
        String[] parts = message.split(":");
        if (parts.length < 2) return;

        String command = parts[0];
        String applianceName = normalizeApplianceName(parts[1]);

        switch (command) {
            case "CONNECT":
                this.applianceName = applianceName;
                instantiateXY(applianceName);
                SwingUtilities.invokeLater(() -> gui.addLogMessage("Client connected: " + applianceName));
                break;

            case "DATA":
                if (parts.length == 3) {
                    try {
                        double power = Double.parseDouble(parts[2]);
                        applianceData.put(applianceName, power);
                        SwingUtilities.invokeLater(() -> gui.addLogMessage("Appliance " + applianceName + " consumption: " + power + "W"));
                        updateTotalConsumption();
                    } catch (NumberFormatException e) {
                        SwingUtilities.invokeLater(() -> gui.addLogMessage("Invalid data from " + applianceName));
                    }
                }
                break;

            case "DISCONNECT":
                SwingUtilities.invokeLater(() -> gui.addLogMessage("Client disconnected: " + applianceName));
                applianceData.remove(applianceName);
                updateTotalConsumption();
                break;
        }
    }

    private String normalizeApplianceName(String applianceName) {
        return applianceName.replaceAll("\\s*\\d*$", "").trim();
    }

    private void instantiateXY(String applianceName) {
        if (!applianceSeriesMap.containsKey(applianceName)) {
            LiveXYSeries<Double> applianceSeries = new LiveXYSeries<>(applianceName, 7);
            applianceSeriesMap.put(applianceName, applianceSeries);

            SwingUtilities.invokeLater(() -> {
                try {
                    gui.addSeries(applianceSeries);
                } catch (IllegalArgumentException e) {
                    System.err.println("Series '" + applianceName + "' already exists. Skipping addition.");
                }
            });
        }
    }



    private void updateTotalConsumption() {
        double totalConsumption = applianceData.values().stream().mapToDouble(Double::doubleValue).sum();
        SwingUtilities.invokeLater(() -> gui.setTotalConsumption(totalConsumption));
    }

    private void cleanup() {
        try {
            if (dataInput instanceof Closeable) {
                ((Closeable) dataInput).close();
            }
        } catch (IOException e) {}

        try {
            if (dataOutput instanceof Closeable) {
                ((Closeable) dataOutput).close();
            }
        } catch (IOException e) {}

        SwingUtilities.invokeLater(() -> gui.addLogMessage("Client " + applianceName + " resources cleaned up."));
    }

    private void diagramMetod() {
        double totalConsumption = applianceData.values().stream().mapToDouble(Double::doubleValue).sum();
        this.clock = System.currentTimeMillis() / 1000;

        totalConsumptionDiagram.addValue(clock, totalConsumption);

        for (String applianceName : applianceSeriesMap.keySet()) {
            LiveXYSeries<Double> applianceSeries = applianceSeriesMap.get(applianceName);
            if (applianceSeries != null) {
                double appliancePower = applianceData.getOrDefault(applianceName, 0.0);
                applianceSeries.addValue(clock, appliancePower);
            }
        }
    }
}
