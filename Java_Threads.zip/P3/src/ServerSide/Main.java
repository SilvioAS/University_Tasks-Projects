package ServerSide;
/**
 * @author Karim, Jonathan, Romeo, Burak
 */

import se.mau.DA343A.VT25.projekt.ServerGUI;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            ServerGUI gui = new ServerGUI("Server");
            gui.createAndShowUI();

            MyServer server = new MyServer(35000, gui);
            new Thread(server).start();
        });

    }
}
