package ServerSide;

import se.mau.DA343A.VT25.projekt.net.ListeningSocket;
import se.mau.DA343A.VT25.projekt.net.ListeningSocketConnectionWorker;
import se.mau.DA343A.VT25.projekt.ServerGUI;

import java.util.concurrent.ConcurrentHashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class MyServer extends ListeningSocket {
    private ServerGUI gui;
    private ConcurrentHashMap<String, Double> applianceData;
    private LinkedHashMap<Long, Double> historicConsumption;

    public MyServer(int port, ServerGUI gui) {
        super(port);
        this.gui = gui;
        this.applianceData = new ConcurrentHashMap<>();
        this.historicConsumption = new LinkedHashMap<>() {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Long, Double> eldest) {
                return size() > 20;
            }
        };

        javax.swing.Timer timer = new javax.swing.Timer(1000, e -> {
            long unixTime = System.currentTimeMillis() / 1000;
            double totalConsumption = applianceData.values().stream().mapToDouble(Double::doubleValue).sum();
            gui.setTotalConsumption(totalConsumption);
            historicConsumption.put(unixTime, totalConsumption);

            for (String appliance : applianceData.keySet()) {
                gui.addLogMessage("Appliance " + appliance + " consumption: " + applianceData.get(appliance) + "W");
            }
        });
        timer.start();
    }

    @Override
    public ListeningSocketConnectionWorker createNewConnectionWorker() {
        return new ClientHandler(gui, applianceData);
    }
}