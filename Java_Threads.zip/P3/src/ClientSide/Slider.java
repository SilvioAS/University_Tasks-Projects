package ClientSide;

import se.mau.DA343A.VT25.projekt.Buffer;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;

public class Slider extends JFrame {

    private JSlider powerSlider;
    private JLabel powerValueLabel;
    private PropertyChangeSupport propertyChangeSupport;
    private String applianceName;
    private int currentValue;
    private Buffer<String> buffer;

    public Slider(String applianceName, int maxPower, Buffer<String> buffer) {
        this.buffer = buffer;

        this.applianceName = applianceName;
        setTitle("Smart Plug - " + applianceName);
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel applianceLabel = new JLabel("Appliance: " + applianceName, SwingConstants.CENTER);
        add(applianceLabel, BorderLayout.NORTH);

        // Slider
        powerSlider = new JSlider(0, maxPower, 0);
        powerSlider.setMajorTickSpacing(maxPower / 5);
        powerSlider.setPaintTicks(true);
        powerSlider.setPaintLabels(true);
        add(powerSlider, BorderLayout.CENTER);

        // Värde
        powerValueLabel = new JLabel("Power: 0W", SwingConstants.CENTER);
        add(powerValueLabel, BorderLayout.SOUTH);

        propertyChangeSupport = new PropertyChangeSupport(this);

        propertyChangeSupport.addPropertyChangeListener("powerConsumption", new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                int newValue = (int) evt.getNewValue();
                currentValue = newValue;
                powerValueLabel.setText("Power: " + newValue + "W");
                //sendDataToServer(newValue);
            }
        });

        powerSlider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if (!powerSlider.getValueIsAdjusting()) {
                    int newPowerValue = powerSlider.getValue();
                    propertyChangeSupport.firePropertyChange("powerConsumption", null, newPowerValue);

                    String applianceData = applianceName + ":" + String.valueOf(newPowerValue) ;


                    buffer.put(applianceData);
                }
            }
        });


        //connectToServer();

        setVisible(true);
    }

    public int getCurrentValue()   {
        return currentValue;
    }
}
