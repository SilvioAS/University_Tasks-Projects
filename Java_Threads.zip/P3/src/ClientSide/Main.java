package ClientSide;
/**
 * @author Karim, Jonathan, Romeo, Burak
 */


public class Main {
    public static void main(String[] args) {

        ClientSimulator simulator = new ClientSimulator();
    }
}