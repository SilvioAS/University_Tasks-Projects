package ClientSide;

import se.mau.DA343A.VT25.projekt.Buffer;
import se.mau.DA343A.VT25.projekt.net.SecurityTokens;

import java.io.*;
import java.net.Socket;

public class Client implements Runnable {
    private Buffer<String> buffer;
    private final String serverAddress = "localhost";
    private final int port = 35000;
    private String applianceName;
    private DataOutputStream outPut;
    private Socket socket;
    private BufferedReader in;
    private DataInputStream input;
    private volatile boolean running = true;
    private String teamName = "DrDar";
    private SecurityTokens tokens;


    public Client(Buffer<String> buffer, String applianceName) {
        this.buffer = buffer;
        this.applianceName = applianceName;
    }

    public void run() {
        try {
            socket = new Socket(serverAddress, port);
            outPut = new DataOutputStream(socket.getOutputStream());
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            input = new DataInputStream(socket.getInputStream());

            try {
                validateThisToken();

            } catch (RuntimeException e) {
                System.out.println("Error: " + e.getMessage());
                e.printStackTrace();
            }

            System.out.println("Connected to server");
            outPut.writeUTF("CONNECT:" + applianceName + " 0");
            outPut.flush();

            while (running) {
                try {
                    String valueToSend = buffer.get();
                    outPut.writeUTF("DATA:" + valueToSend);
                    outPut.flush();
                    System.out.println("Sent to server: " + valueToSend);

                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    System.out.println("Interrupted: " + e.getMessage());
                    running = false;
                }
            }

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        } catch (RuntimeException e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
         } finally {
            disconnect();
        }
    }

    private void validateThisToken() {
        tokens = new SecurityTokens(teamName);
        int maxRetries = 3;
        int attempts = 0;

        while (attempts < maxRetries) {
            attempts++;
            String generatedToken = tokens.generateToken();

            try {
                outPut.writeUTF(generatedToken);
                outPut.flush();
                System.out.println("Sent token validation request (Attempt " + attempts + ")");

                String validationsAnswer = input.readUTF();

                if (validationsAnswer.equals("ACK")) {
                    System.out.println("Token Accepted!");
                    return;
                } else if (validationsAnswer.equals("NACK")) {
                    System.out.println("Token Rejected! Retrying...");
                    Thread.sleep(1000);
                }

            } catch (IOException | InterruptedException e) {
                System.err.println("Error during token validation: " + e.getMessage());
            }
        }

        System.out.println("Token validation failed after " + maxRetries + " attempts. Exiting...");
        throw new RuntimeException("Token validation failed after " + maxRetries + " attempts.");
    }

    private void disconnect() {
        running = false;

        try {
        if (outPut != null) {
            outPut.writeUTF("DISCONNECT:" + applianceName);
            outPut.close();
        }
        if (in != null) {
            in.close();
        }
        if (socket != null && !socket.isClosed()) {
            socket.close();
        }
        System.out.println("Disconnected from server");
        } catch (IOException e) {
            System.err.println("Error while disconnecting: " + e.getMessage());
        }
    }
}
