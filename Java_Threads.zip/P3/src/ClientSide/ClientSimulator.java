package ClientSide;

import se.mau.DA343A.VT25.projekt.Buffer;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class ClientSimulator {

    public List<Slider> allSliders = new ArrayList<>();
    public List<Client> allClients = new ArrayList<>();
    private Buffer<String> buffer = new Buffer<>();

    public ClientSimulator() {

        // Lägger till alla JSliders
        createAndAddSliders();


        // Skriver ut totala power varje sekund
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Slider total value: " + getTotalPower());
            }
        });
        timer.start();


    }

    public int getTotalPower() {
        int currentTotalValue = 0;
        for (Slider client : allSliders) {
            currentTotalValue += client.getCurrentValue();
        }
        return currentTotalValue;

    }


    public void createAndAddSliders() {

        String[] applianceNames = {"LED Light Bulb", "Incandescence Bulb",
                                    "Laptop", "Desktop Computer", "TV (LED)",
                                    "Refrigerator", "Microwave Oven"};
        int[] maxPowers = {15, 40, 30, 200, 150, 250, 1000};

        for (int i = 0; i < applianceNames.length; i++) {
            //Buffer<Integer> buffer = new Buffer<>();
            Slider slider = new Slider(applianceNames[i], maxPowers[i], buffer);
            allSliders.add(slider);

            Client client = new Client(buffer, applianceNames[i]);
            Thread clientThread = new Thread(client);
            clientThread.start();
            allClients.add(client);
        }


        /*
        Slider led = new Slider("LED Light Buld", 15, this, this.buffer);
        allSliders.add(led);
        Slider incandescence = new Slider("Incandescence Bulb", 40, this, this.buffer);
        allSliders.add(incandescence);
        Slider laptop = new Slider("Laptop", 30, this, this.buffer);
        allSliders.add(laptop);
        Slider desktop = new Slider("Desktop Computer", 200, this, this.buffer);
        allSliders.add(desktop);
        Slider tv = new Slider("TV (LED)", 150, this, this.buffer);
        allSliders.add(tv);
        Slider refrigerator = new Slider("Refrigerator", 250, this, this.buffer);
        allSliders.add(refrigerator);
        Slider MicrowaveOven = new Slider("Microwave Oven", 1000, this, this.buffer);
        allSliders.add(MicrowaveOven);

         */

    }
}