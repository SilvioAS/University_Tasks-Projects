package model;

public class Player {
    private int medlemar;
    private int points;

    /**
     * this contructor is used to initialize the values of a player
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */

    public Player(){
        medlemar = 3; //Default value
        points = 0; //Default value
    }

    /**
     * this getter is used to get the amount of members a player has
     * @return int the amount of members left
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public int getMedlemar() {
        return medlemar;
    }

    /**
     * this setter is used to set the amount of members a player has
     * @param medlemar
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public void setMedlemar(int medlemar) {
        this.medlemar = medlemar;
    }

    /**
     * this method is used to add to the total of members a player has
     * @param medlemar the number of medlemar to add to the current total
     */
    public void addMedlemar(int medlemar) {
        this.medlemar = this.medlemar + medlemar;
    }

    /**
     * this getter is used to get the amount of points a player has
     */
    public int getPoints() {
        return points;
    }

    /**
     * this setter is used to set the number of points a player has
     * @param points the number of points to add to the current total
     */
    public void addPoints(int points) {
        this.points = this.points + points;
    }

    public void resetPoints(){
        this.points = 0;
    }
}
