package model;

/**
 * this inteface is in controller to save the grid
 * @Author - Romeo Andersson Saavedra, aq3574
 *
 */
public interface GridObjekt {
}