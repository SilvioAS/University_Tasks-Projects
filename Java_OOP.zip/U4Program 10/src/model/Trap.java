package model;

public class Trap implements GridObjekt{
}