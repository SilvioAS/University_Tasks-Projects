package model;

/**
 * the reason for the enum is for the different players turns
 * @Author - Romeo Andersson Saavedra, aq3574
 * @Author - Karim Charania, aq1143
 */
public enum CurrentPlayerTurn {
    PLAYER_ONE,
    PLAYER_TWO;
}