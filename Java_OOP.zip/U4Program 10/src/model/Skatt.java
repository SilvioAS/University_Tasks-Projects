package model;

public class Skatt implements GridObjekt{
    private int size;
    private int originalSize;

    /**
     * this constructor is used to initialize the positions of the skatt and its neighbors
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     * @param size is the size of the treasure
     **/
    public Skatt(int size) {
        this.size = size;
        originalSize = size;
    }

    public int getOriginalSize() {
        return originalSize;
    }

    public boolean checkIfFound(){
        size--;
        if (size == 0){
            System.out.println("Skatt has been found!!!");
            return true;
        }

        System.out.println("HIT");

        return false;
    }
}