package model;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HighscoreModel {
    private final int MAX_HIGHSCORES = 10;
    private List<Highscore> highscores;

    /**
     * Initializes the HighscoreModel and loads the highscores.
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public HighscoreModel() {
        highscores = new ArrayList<>();
        loadHighscores();
    }

    /**
     * Adds a new highscore to the list and ensures the list is sorted and limited to the max size.
     * @param name the name of the player for the highscore
     * @param score the score the player achieved
     */
    public void addHighscore(String name, int score) {
        highscores.add(new Highscore(name, score));
        highscores.sort(Comparator.comparingInt(Highscore::getScore).reversed()); // Sort in descending order
        if (highscores.size() > MAX_HIGHSCORES) {
            highscores.remove(highscores.size() - 1); // Remove the last element if the list exceeds the max size
        }
        saveHighscores(); // Save the entire list after the update
    }

    /**
     * Loads the highscores from the saved file.
     */
    private void loadHighscores() {
        File file = new File("/Users/karimcharania/Desktop/highscores.txt");

        if (!file.exists()) {
            System.err.println("Highscores file does not exist. Initializing empty highscores.");
            return; // Return early if the file doesn't exist.
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {  // Ensure the line is in the correct format
                    String name = parts[0].trim();  // Trim any extra spaces from the name
                    int score = Integer.parseInt(parts[1].trim());  // Trim extra spaces from the score and parse it
                    highscores.add(new Highscore(name, score));
                } else {
                    System.err.println("Invalid line in highscores file: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading highscores.txt: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid score format in highscores.txt: " + e.getMessage());
        }
    }



    /**
     * Saves the current highscores list to the file.
     */
    public void saveHighscores() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("/Users/karimcharania/Desktop/highscores.txt"))) {
            for (Highscore highscore : highscores) {
                writer.write(highscore.getName() + "," + highscore.getScore());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing to highscores.txt: " + e.getMessage());
        }
    }

    /**
     * Returns the current list of highscores.
     * @return a list of highscores
     * @Author - Karim Charania, aq1143
     */
    public List<Highscore> getHighscores() {
        return highscores;
    }
}
