package model;


public class Highscore {
    private String name;
    private int score;

    /**
     * this contructor is it initializes a new instance of the Highscore, with the specific value of name and score
     * @Author - Karim Charania, aq1143
     * @param name represents name of the player
     * @param score represents score of the player
     *
     */

    public Highscore(String name, int score) {
        this.name = name;
        this.score = score;
    }

    /**
     * Gettor to get the name of the player
     * @Author - Karim Charania, aq1143
     * @return String
     */
    public String getName() {
        return name;
    }

    /**
     * is used to set score of the player
     * @Author - Karim Charania, aq1143
     * @param score
     */

    public void setScore(int score){
        this.score = score;
    }

    /**
     *Is used to get the score
     * @Author - Karim Charania, aq1143
     * @return int
     */

    public int getScore() {
        return score;
    }

    /**
     * is used to set the name of the player
     * @Author - Karim Charania, aq1143
     * @param name
     */
    public void setName(String name){
        this.name = name;
    }
}
