package model;

/**
 * the bonus class represent the object that is on the game grid
 */
public class Bonus implements GridObjekt{
}
