package view;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controller.Controller;

public class PanelCenter extends JPanel {
    private Controller controller;
    private static final int grid_Size = 10; //10x10 grid
    private JButton[][] gridButtons;
    private int buttonsPressed = 0;

    /**
     * this contructor is used to initialize the game board
     * @param controller the controller handles the game logic
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public PanelCenter(Controller controller){
        this.controller = controller;

        setLayout(new GridLayout(grid_Size, grid_Size));
        gridButtons = new JButton[grid_Size][grid_Size];

        createButtons();
    }

    /**
     * this method is used to create the buttons which are in the map
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    private void createButtons(){
        int select = chooseMap();
        controller.setMap(select);

        for (int y = 0; y < grid_Size; y++) {
            for (int x = 0; x < grid_Size; x++) {
                JButton button = new JButton();
                button.setPreferredSize(new Dimension(10, 10)); // Set button size
                button.addActionListener(new ButtonClicklistener(y, x));
                gridButtons[y][x] = button;
                add(button); // Add button to the panel
            }
        }
    }



    /**
     * this method is used to get the choice of map from the user
     * @return int for the map chosen
     * @Author - Romeo Andersson Saavedra, aq3574
     *
     */
    public int chooseMap(){
        String[] options = { "Map1", "Map 2"};

        int select = JOptionPane.showOptionDialog(null, "Select map: ", "Map", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        return select;
    }

    /**
     * this method is used to disable all buttons on the game board
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public void disableAllButtons(){
        for (int y = 0; y < grid_Size; y++) {
            for (int x = 0; x < grid_Size; x++) {
                gridButtons[y][x].setEnabled(false);
            }
        }
    }

    /**
     * this method is used to reset the buttons on the game grid by enabling it
     * @Author - Karim Charania, aq1143
     */
    public void resetButtons(){
        for (int y = 0; y < grid_Size; y++) {
            for (int x = 0; x < grid_Size; x++) {
                gridButtons[y][x].setEnabled(true);
                gridButtons[y][x].setText("");
            }
        }
    }

    public void setButtonType(int y,int x, String type){
        gridButtons[y][x].setText(type);
    }


    private class ButtonClicklistener implements ActionListener{
        private int row;
        private int col;

        /**
         * this contructor is used to initialize the rows and columns for the button click listener
         * @param row the row index of the buttons in the grid
         * @param col the column index of the buttons in the grid
         * @Author - Romeo Andersson Saavedra, aq3574
         * @Author - Karim Charania, aq1143
         */
        public ButtonClicklistener(int row, int col){
            this.row = row;
            this.col = col;
        }

        /**
         * this method handles the action when a button is clicked in the game grid
         * @param e the event that happens when a button is clicked
         * @Author - Romeo Andersson Saavedra, aq3574
         * @Author - Karim Charania, aq1143
         */
        @Override
        public void actionPerformed(ActionEvent e){
            JButton button = (JButton) e.getSource();//Set variable for button that was clicked

            controller.whatWasHit(row,col);

            button.setEnabled(false);
            buttonsPressed++;
            if(buttonsPressed == 100){
                controller.resetMap();
                buttonsPressed = 0;
            }
        }
    }
}
