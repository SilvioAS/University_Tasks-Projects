package view;

import controller.Controller;
import javax.swing.*;
import javax.swing.JOptionPane;

public class MainView {
    private JFrame frame;

    private int height = 800;
    private int width = 1000;

    private MainPanel panel;

    /**
     * this contructor is used to initialize the game window
     * @param controller the game logic
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public MainView(Controller controller){
        frame = new JFrame("Skattjakt!");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// makes it closable
        frame.setSize(width, height);// Configures the size

        panel = new MainPanel(width, height, controller);
        frame.add(panel);
        frame.pack();
        frame.setVisible(true);
    }

    /**
     * this method is used to get the MainPanel
     * @return the main panel MainPanel
     * @Author - Karim Charania, aq1143
     */
    public MainPanel getPanel() {
        return panel;
    }

    /**
     * prompt to ask the user to enter their name for highscore
     * @return the player 1 name
     */

    public String writeNamePlayer1(){



        return JOptionPane.showInputDialog("Enter name for Player 1");

    }
    /**
     * prompt to ask the user to enter their name for highscore
     * @return the player 2 name
     */
    public String writeNamePlayer2(){



        return JOptionPane.showInputDialog("Enter name for Player 2");

    }

    /**
     * this method is used to display a pop up message
     * @param s is the message that is to be displayed
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public void showMessage(String s){
        JOptionPane.showMessageDialog(null, s);
    }
}