package view;

import controller.Controller;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import java.awt.*;

public class MainPanel extends JPanel {
    private Controller controller;

    private int height;
    private int width;

    private PanelNorth NorthP;
    private PanelCenter CenterP;
    private PanelSouth SouthP;
    private PanelWest WestP;

    /**
     * this method is used to initialize the gui with the specified
     * @param width is the width of the gui
     * @param height is the height of the gui
     * @param controller is the logic of the game
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */

    public MainPanel(int width, int height, Controller controller){
        this.controller = controller;
        this.height = height;
        this.width = width;

        setPreferredSize(new Dimension(width, height));

        panelSetup();
    }

    /**
     * this method is used to set up the gui panel and arrange the different panels
     *@Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    private void panelSetup(){
        BorderLayout layout = new BorderLayout();
        setLayout(layout);

        Border border = this.getBorder();

        Border margin = BorderFactory.createEmptyBorder(10,10,10,10);
        setBorder(new CompoundBorder(border, margin));

        NorthP = new PanelNorth();
        CenterP = new PanelCenter(controller);
        SouthP = new PanelSouth(controller);
        WestP = new PanelWest(controller);


        add(NorthP, BorderLayout.NORTH);
        add(WestP, BorderLayout.WEST);
        add(CenterP, BorderLayout.CENTER);
        add(SouthP, BorderLayout.SOUTH);
    }


    /**
     * this method is used to return the North Panel
     * @return the north panel PanelNorth
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public PanelNorth getPanelNorth(){
        return NorthP;
    }


    /**
     * this method is used to return the South Panel
     * @return the south panel PanelSouth
     * @Author - Karim Charania, aq1143
     */
    public PanelSouth getSouthP() {
        return SouthP;
    }

    /**
     * this method is used to return the center panel
     * @return the center panel PanelCenter
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public PanelCenter getCenterP() {
        return CenterP;
    }
}