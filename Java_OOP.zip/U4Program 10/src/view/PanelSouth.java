package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import controller.Controller;

public class PanelSouth extends JPanel {
    private JButton btnExit;
    private JButton btnRestart;
    private Controller controller;
    private JLabel lblCurrentPlayer;

    /**
     * this constructor is used to initialize panel south with the buttons and set up their actions
     * @param controller is the game logic for the button actions
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public PanelSouth(Controller controller){
        this.controller = controller;
        btnExit = new JButton("Exit");
        Dimension dim = new Dimension(50, 25);
        btnExit.setSize(dim);

        btnRestart = new JButton ("Reset");
        btnRestart.setSize(dim);

        lblCurrentPlayer = new JLabel("Current Player: Player 1");//Default
        lblCurrentPlayer.setSize(dim);

        add(btnExit);
        add(btnRestart);
        add(lblCurrentPlayer);
        btnExit.addActionListener(new ButtonActionListeners());
        btnRestart.addActionListener(new ButtonActionListeners());
    }
    public void setLblCurrentPlayer(String s){
        lblCurrentPlayer.setText("Current Player: " + s);
    }

    class ButtonActionListeners implements ActionListener{

        /**
         * this method is used for the exit and reset buttons
         * @param e is the button clicked
         * @Author - Romeo Andersson Saavedra, aq3574
         * @Author - Karim Charania, aq1143
         */
        @Override
        public void actionPerformed(ActionEvent e){
            if(e.getSource() == btnExit){
                controller.exitButtonPressed();
            }else if(e.getSource() == btnRestart){
                controller.resetMap();
            }
        }
    }
}