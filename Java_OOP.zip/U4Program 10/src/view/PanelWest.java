package view;

import controller.Controller;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;


public class PanelWest extends JPanel {
    private JList<String> list;
    private DefaultListModel<String> listModel;
    private Controller controller;
    private JButton highscoreButton;

    /**
     * this constructor is used to initialize the panel west, button and highscore list
     * @param controller is the game logic for the button action
     * @Author - Karim Charania, aq1143
     */
    public PanelWest(Controller controller) {
        this.controller = controller;
        Font font = new Font("Arial", Font.PLAIN, 14);

        highscoreButton = new JButton("Show Highscores");
        Dimension dim = new Dimension(150, 25);
        highscoreButton.setSize(dim);
        highscoreButton.setActionCommand("ShowHighscores");

        listModel = new DefaultListModel<>();
        list = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(list);

        setLayout(new BorderLayout());
        add(highscoreButton, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        highscoreButton.addActionListener(new ButtonActionListeners());
    }

    class ButtonActionListeners implements ActionListener {

        /**
         * this method is used to handle the process when the history button is pressed, read the highscore list from the list
         * @param e the event of clicking the button
         * @Author - Karim Charania, aq1143
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == highscoreButton) {
                listModel.clear();
                try (BufferedReader reader = new BufferedReader(new FileReader("/Users/karimcharania/Desktop/highscores.txt"))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        listModel.addElement(line);
                    }
                } catch (IOException ex) {
                    System.err.println("Error reading highscores.txt: " + ex.getMessage());
                }
            }
        }
    }
}