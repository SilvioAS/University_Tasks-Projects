package view;

import javax.swing.*;
import java.awt.*;

public class PanelNorthLeft extends JPanel {
    private JLabel playerLbl;
    private JLabel mellanrum;
    private JLabel medlemarLbl;
    private JLabel pointsLbl;

    /**
     * this method is used to create the Panel north left and labels
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public PanelNorthLeft(){
        createInfoLabels();
    }

    /**
     * this method is used to create the info label of the player, members, and points
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    private void createInfoLabels(){
        setLayout(new GridLayout(4,1)); // Use GridLayout
        Font font = new Font("Arial", Font.PLAIN, 14);

        playerLbl = new JLabel("Player 1:");//set playerLbl
        playerLbl.setPreferredSize(new Dimension(400,20));
        playerLbl.setFont(font);

        mellanrum = new JLabel("--------------");//Set Playerlbl
        mellanrum.setPreferredSize(new Dimension(400,20));
        mellanrum.setFont(font);

        medlemarLbl = new JLabel("Besättnings Medlemmar: ");// set medlemarLbl
        medlemarLbl.setPreferredSize(new Dimension(400,20));
        medlemarLbl.setFont(font);

        pointsLbl = new JLabel("Poäng: 0");//Set pointsLbl
        pointsLbl.setPreferredSize(new Dimension(400,20));
        pointsLbl.setFont(font);

        add(playerLbl);
        add(mellanrum);
        add(medlemarLbl);
        add(pointsLbl);
    }

    /**
     * this method is used to set the number of members for player 1 within the north left panel
     * @param s is the number of members to display
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    public void setMedlemmarLbl(int s){
        medlemarLbl.setText("Besättnings Medlemmar: " + s);
    }

    /**
     * this method is used to set the number of points for player 1 within the north right panel
     * @param s is the number of points to display
     * @Author - Karim Charania, aq1143
     */
    public void setPointsLbl(int s){
        pointsLbl.setText("Poäng: " + s);
    }
}
