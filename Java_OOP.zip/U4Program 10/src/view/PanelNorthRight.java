package view;

import javax.swing.*;
import java.awt.*;

public class PanelNorthRight extends JPanel {
    private JLabel playerLbl;
    private JLabel mellanrum;
    private JLabel medlemarLbl;
    private JLabel pointsLbl;

    /**
     * this constructor is used to create the Panel north right labels
     *  @Author - Romeo Andersson Saavedra, aq3574
     *  @Author - Karim Charania, aq1143
     */

    public PanelNorthRight(){
        createInfoLabels();
    }

    /**
     * this method is used to create the info labels which display the player, member count, and points
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    private void createInfoLabels(){
        setLayout(new GridLayout(4,1)); // Use Gridlayout
        Font font = new Font("Arial", Font.PLAIN, 14);

        playerLbl = new JLabel("Player 2:");//Set Playerlbl
        playerLbl.setPreferredSize(new Dimension(400,20));
        playerLbl.setFont(font);

        mellanrum = new JLabel("--------------");//Set Playerlbl
        mellanrum.setPreferredSize(new Dimension(400,20));
        mellanrum.setFont(font);

        medlemarLbl = new JLabel("Besättnings Medlemmar: ");// set medlemarLbl
        medlemarLbl.setPreferredSize(new Dimension(400,20));
        medlemarLbl.setFont(font);

        pointsLbl = new JLabel("Poäng: 0");//Set pointsLbl
        pointsLbl.setPreferredSize(new Dimension(400,20));
        pointsLbl.setFont(font);

        add(playerLbl);
        add(mellanrum);
        add(medlemarLbl);
        add(pointsLbl);
    }

    /**
     * this method is used to set the members for player 2 within the north left panel
     * @param s is the amount of members to be displayed
     *  @Author - Romeo Andersson Saavedra, aq3574
     */
    public void setMedlemmarLbl(int s){
        medlemarLbl.setText("Besättnings Medlemmar: " + s);
    }

    /**
     * this method is used to set the points for player 2 within the north left panel
     * @param s is the amount of points to be displayed
     * @Author - Karim Charania, aq1143
     */
    public void setPointsLbl(int s){
        pointsLbl.setText("Poäng: " + s);
    }
}
