package view;

import javax.swing.*;
import java.awt.*;

public class PanelNorth extends JPanel{

    private PanelNorthRight rightSide;
    private PanelNorthLeft leftSide;

    /**
     * this contructor is used initialize the North panel of the gui
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public PanelNorth(){
        panelSetup();
    }

    /**
     * this method is used to setup the north right and north left of the nothern panel
     * @Author - Romeo Andersson Saavedra, aq3574
     */
    private void panelSetup(){
        setLayout(new BorderLayout());

        leftSide = new PanelNorthLeft();
        rightSide = new PanelNorthRight();

        add(leftSide, BorderLayout.WEST);
        add(rightSide, BorderLayout.EAST);
    }

    /**
     * this method is used to get the right side of the northern panel
     * @return the north right panel PanelNorthRight
     * @Author - Karim Charania, aq1143
     */
    public PanelNorthRight getRightSide() {
        return rightSide;
    }

    /**
     * this method is used to get the left side of the nothern panel
     * @return the north left panel PanelNorthLeft
     * @Author - Karim Charania, aq1143
     */
    public PanelNorthLeft getLeftSide() {
        return leftSide;
    }
}
