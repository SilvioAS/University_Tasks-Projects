/**
 * This class is used to create the game board which is used by the user
 * @Author - Karim Charania, aq1143
 * @Author - Romeo Andersson Saavedra, aq3574
 */

package controller;

import model.*;
import view.MainView;

import javax.swing.*;


public class Controller {
    private MainView view;
    private CurrentPlayerTurn currentPlayer = CurrentPlayerTurn.PLAYER_ONE;//start value
    private Player[] players = new Player[2];
    private HighscoreModel highscoreModel = new HighscoreModel();
    private GridObjekt[][] gridObjekts;

    /**
     * Constructor for the controller class,
     * Makes an instance of gridObjekts, which creates the gameboard
     */

    public Controller() {
        gridObjekts = new GridObjekt[10][10];
        view = new MainView(this);//Start GUI thru MainView class
        players[0] = new Player();//Create player 1
        players[1] = new Player();//Create Player 2
        view.getPanel().getPanelNorth().getLeftSide().setMedlemmarLbl(players[0].getMedlemar());
        view.getPanel().getPanelNorth().getRightSide().setMedlemmarLbl(players[1].getMedlemar());
    }

    /**
     * This method determines what was hit on the game grid and updates the UI accordingly depending on what object was hit
     * @param y the y coordinate of the grid
     * @param x the x coordinate of the grid
     */
    public void whatWasHit(int y, int x){
        if(gridObjekts[y][x] instanceof Skatt){
            Skatt skatt = (Skatt) gridObjekts[y][x];
            if(skatt.checkIfFound()){
                addPointsToPlayer(skatt);
            }
            view.getPanel().getCenterP().setButtonType(y, x,"S");
        }else if(gridObjekts[y][x] instanceof Trap){
            view.getPanel().getCenterP().setButtonType(y, x,"T");
            ifPlayerGetsTrap();
        }else if(gridObjekts[y][x] instanceof Bonus){
            view.getPanel().getCenterP().setButtonType(y, x,"B");
            ifPlayerGetsBonus();
        }else{
            view.getPanel().getCenterP().setButtonType(y,x, "X");
        }

        if (!CurrentTurn()) {
            view.getPanel().getCenterP().disableAllButtons();

        }
    }

    /**
     *
     * this method is used to add points to a players if called upon, it check what person is current playing and gives the points accordingly
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     * @param skatt
     */
    private void addPointsToPlayer(Skatt skatt) {
        int amount = skatt.getOriginalSize();
        switch (currentPlayer) {
            case PLAYER_ONE:
                players[0].addPoints(amount);
                //System.out.println("Player 1 got points");
                JOptionPane.showMessageDialog(null,"Player 1 has been rewarded "+ amount + " points");
                view.getPanel().getPanelNorth().getLeftSide().setPointsLbl(players[0].getPoints());
                break;
            case PLAYER_TWO:
                players[1].addPoints(amount);
                //System.out.println("Player 2 got points");
                JOptionPane.showMessageDialog(null,"Player 2 has been rewarded "+ amount + " points");
                view.getPanel().getPanelNorth().getRightSide().setPointsLbl(players[1].getPoints());
                break;
        }
    }

    /**
     * this method is used to check if the player has 0 members left, if he does, it will output the winner
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     * @return
     *
     */
    public boolean CurrentTurn() {
        switch (currentPlayer) {
            case PLAYER_ONE:
                view.getPanel().getPanelNorth().getLeftSide().setMedlemmarLbl(players[0].getMedlemar());

                if (players[0].getMedlemar() <= 0) {
                    whoWon();
                    return false;
                }

                currentPlayer = CurrentPlayerTurn.PLAYER_TWO; //Change player
                view.getPanel().getSouthP().setLblCurrentPlayer("player 2:");
                break;
            case PLAYER_TWO:
                view.getPanel().getPanelNorth().getRightSide().setMedlemmarLbl(players[1].getMedlemar());

                if (players[1].getMedlemar() <= 0) {
                    whoWon();
                    return false;
                }

                currentPlayer = CurrentPlayerTurn.PLAYER_ONE; //Change player
                view.getPanel().getSouthP().setLblCurrentPlayer("Player 1");
                break;
        }

        return true;
    }

    /**
     * determines the winner based on points and updates the highscore List
     */
    private void whoWon(){
        if (players[0].getPoints() > players[1].getPoints()){
            view.showMessage("Player 1 Wins!!!");
            int score = players[0].getPoints();
            String name = view.writeNamePlayer1();

            // Add Player 1's score to the highscore list
            highscoreModel.addHighscore(name, score);
        } else if (players[0].getPoints() < players[1].getPoints()){
            view.showMessage("Player 2 Wins!!!");
            int score = players[1].getPoints();
            String name = view.writeNamePlayer2();

            // Add Player 2's score to the highscore list
            highscoreModel.addHighscore(name, score);
        } else {
            view.showMessage("DRAW!!! NOBODY WINS!!!");
        }
    }



    /**
     * this method is used to get the gridobjekt
     * @return gridObjekts
     */

    public GridObjekt[][] getGridObjekts() {
        return gridObjekts;
    }



    /**
     * this method is used to save the current highscore with name and point
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    /*
    public void saveHighScores() {
        for (int i = 0; i < highscores.length; i++) {
            if (highscores[i] == null) {
                if (players[0].getPoints() > players[1].getPoints()) {
                    String name = JOptionPane.showInputDialog("Enter name");
                    int score = players[0].getPoints();

                    if (name != null) {
                        highscores[i] = new Highscore(name, score);
                    }

                    highscoreModel.addHighscore(highscores[i].getName(), highscores[i].getScore());
                }if (players[0].getPoints() < players[1].getPoints()) {

                    String name = JOptionPane.showInputDialog("Enter name");
                    int score = players[1].getPoints();

                    if (name != null) {
                        highscores[i] = new Highscore(name, score);
                    }

                    highscoreModel.addHighscore(highscores[i].getName(), highscores[i].getScore());
                }
                break;
            }
        }
    }
    */

    /**
     * this method is used to close the program
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public void exitButtonPressed() {
        System.exit(0);
    }

    /**
     * This method is used to give the player a bonus
     * @Author - Karim Charania, aq1143
     */
    public void ifPlayerGetsBonus() {
        switch (currentPlayer) {
            case PLAYER_ONE:
                players[0].addMedlemar(2);
                view.getPanel().getPanelNorth().getLeftSide().setMedlemmarLbl(players[0].getMedlemar());
                break;
            case PLAYER_TWO:
                players[1].addMedlemar(2);
                view.getPanel().getPanelNorth().getRightSide().setMedlemmarLbl(players[1].getMedlemar());
                break;
        }
    }

    /**
     * Gives the player one less member in his expedition
     */
    public void ifPlayerGetsTrap(){
        switch (currentPlayer) {
            case PLAYER_ONE:
                if (players[0].getPoints() != 0) {
                    players[0].addPoints(-1);
                    view.getPanel().getPanelNorth().getLeftSide().setPointsLbl(players[0].getPoints());
                }
                break;
            case PLAYER_TWO:
                if (players[0].getPoints() != 0) {
                    players[0].addPoints(-1);
                    view.getPanel().getPanelNorth().getRightSide().setPointsLbl(players[1].getPoints());
                }
                break;
        }
    }

    /**
     * this method is used to select the map, and also hard codes the different object on the game grid
     * @param mapSelection
     */

    public void setMap(int mapSelection){

        if (mapSelection == 0){
            System.out.println("Map 1");

            //Skatter -------------------------
            Skatt skatt = new Skatt(4);
            gridObjekts[0][0] = skatt;
            gridObjekts[1][0] = skatt;
            gridObjekts[1][1] = skatt;
            gridObjekts[1][2] = skatt;

            skatt = new Skatt(3);
            gridObjekts[2][5] = skatt;
            gridObjekts[2][6] = skatt;
            gridObjekts[3][4] = skatt;

            gridObjekts[1][9] = new Skatt(1);

            gridObjekts[3][3] = new Skatt(1);

            skatt = new Skatt(3);
            gridObjekts[5][1] = skatt;
            gridObjekts[6][1] = skatt;
            gridObjekts[7][1] = skatt;

            skatt = new Skatt(3);
            gridObjekts[8][3] = skatt;
            gridObjekts[8][4] = skatt;
            gridObjekts[9][3] = skatt;

            skatt = new Skatt(2);
            gridObjekts[8][7] = skatt;
            gridObjekts[8][8] = skatt;

            skatt = new Skatt(4);
            gridObjekts[5][6] = skatt;
            gridObjekts[5][7] = skatt;
            gridObjekts[5][8] = skatt;
            gridObjekts[6][7] = skatt;

            //Bonus ----------------------------
            Bonus bonus = new Bonus();
            gridObjekts[5][3] = bonus;

            bonus = new Bonus();
            gridObjekts[8][5] = bonus;

            bonus = new Bonus();
            gridObjekts[3][7] = bonus;

            bonus = new Bonus();
            gridObjekts[3][1] = bonus;

            bonus = new Bonus();
            gridObjekts[1][7] = bonus;

            //Fällor -----------------------------
            Trap trap = new Trap();
            gridObjekts[1][5] = trap;

            trap = new Trap();
            gridObjekts[1][5] = trap;

            trap = new Trap();
            gridObjekts[0][1] = trap;

            trap = new Trap();
            gridObjekts[3][8] = trap;

            trap = new Trap();
            gridObjekts[4][6] = trap;

            trap = new Trap();
            gridObjekts[7][4] = trap;

        } else if (mapSelection == 1) {
            System.out.println("Map2");
            Skatt skatt = new Skatt(2);
            gridObjekts[0][1] = skatt;
            gridObjekts[1][1] = skatt;

            skatt = new Skatt(4);
            gridObjekts[0][4] = skatt;
            gridObjekts[0][5] = skatt;
            gridObjekts[1][5] = skatt;
            gridObjekts[1][6] = skatt;

            skatt = new Skatt(3);
            gridObjekts[4][0] = skatt;
            gridObjekts[4][1] = skatt;
            gridObjekts[4][2] = skatt;

            skatt = new Skatt(4);
            gridObjekts[7][7] = skatt;
            gridObjekts[6][7] = skatt;
            gridObjekts[6][6] = skatt;
            gridObjekts[7][6] = skatt;

            skatt = new Skatt(2);
            gridObjekts[9][9] = skatt;
            gridObjekts[8][9] = skatt;

            gridObjekts[7][4] = new Skatt(1);

            gridObjekts[3][3] = new Skatt(1);

            skatt = new Skatt(2);
            gridObjekts[2][2] = skatt;
            gridObjekts[3][2] = skatt;



            Bonus bonus = new Bonus();
            gridObjekts[0][0] = bonus;

            bonus = new Bonus();
            gridObjekts[1][0] = bonus;

            bonus = new Bonus();
            gridObjekts[0][9] = bonus;

            bonus = new Bonus();
            gridObjekts[0][6] = bonus;

            bonus = new Bonus();
            gridObjekts[5][5] = bonus;



            Trap trap = new Trap();
            gridObjekts[8][2] = trap;

            trap = new Trap();
            gridObjekts[4][9] = trap;

            trap = new Trap();
            gridObjekts[6][9] = trap;

            trap = new Trap();
            gridObjekts[9][6] = trap;

            trap = new Trap();
            gridObjekts[5][3] = trap;

            trap = new Trap();
            gridObjekts[5][2] = trap;

        }
    }

    /**
     * this method is used to reset the map, and allow the uset to pick which gameboard to play
     * @Author - Romeo Andersson Saavedra, aq3574
     * @Author - Karim Charania, aq1143
     */
    public void resetMap() {
        int select = view.getPanel().getCenterP().chooseMap();
        setMap(select);

        players[0].setMedlemar(3);
        players[1].setMedlemar(3);
        players[0].resetPoints();
        players[1].resetPoints();

        view.getPanel().getSouthP().setLblCurrentPlayer("Player 1");
        currentPlayer = CurrentPlayerTurn.PLAYER_ONE;
        view.getPanel().getPanelNorth().getLeftSide().setMedlemmarLbl(3);
        view.getPanel().getPanelNorth().getRightSide().setMedlemmarLbl(3);
        view.getPanel().getPanelNorth().getLeftSide().setPointsLbl(0);
        view.getPanel().getPanelNorth().getRightSide().setPointsLbl(0);
        view.getPanel().getCenterP().resetButtons();
    }
}