/**
 * this class is used to start the program
 *
 * @Author - Karim Charania, aq1143
 * @Author - Romeo Andersson Saavedra, aq3574
 */

package controller;

public class Main {
    public static void main(String[] args){
        Controller controller = new Controller();
    }
}