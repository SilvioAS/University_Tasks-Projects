package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

//null,   empty string   and  non-empty string

class rovarTest {
    @Test
    void enrovNull() {
        assertNull(rovar.enrov(null));
    }

    @Test
    void enrovEmptyString() {
        assertEquals("", rovar.enrov(""));
    }

    @Test
    void enrovNon_EmptyStringUpper() {
        assertEquals("ABOBCOCDODEFOFGOGHOHIJOJKOKLOLMOMNONOPOPQOQRORSOSTOTUVOVWOWXOXYZOZÅÄÖ",rovar.enrov("ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ"));
    }

    @Test
    void enrovNon_EmptyStringLower() {
        assertEquals("abobcocdodefofgoghohijojkoklolmomnonopopqoqrorsostotuvovwowxoxyzozåäö",rovar.enrov("abcdefghijklmnopqrstuvwxyzåäö"));
    }

    @Test
    void enrov_ConstantsUpper(){
        assertEquals("BOBCOCDODFOFGOGHOHJOJKOKLOLMOMNONPOPQOQRORSOSTOTVOVWOWXOXZOZ",rovar.enrov("BCDFGHJKLMNPQRSTVWXZ"));
    }

    @Test
    void derov_ConstantsLower(){
        assertEquals("bobcocdodfofgoghohjojkoklolmomnonpopqoqrorsostotvovwowxoxzoz",rovar.enrov("bcdfghjklmnpqrstvwxz"));
    }

    @Test
    void enrovNon_EmptyStringUpperNumbers() {
        assertEquals("0123456789", rovar.enrov("0123456789"));
    }

    @Test
    void enrovNon_EmptyStringCharacters() {
        assertEquals(" !”#€%&/(),.", rovar.enrov(" !”#€%&/(),."));
    }

    //------------- ------------- ------------- ------------- -------------
    //------------- ------------- ------------- ------------- -------------

    @Test
    void derovNull() {
        assertNull(rovar.enrov(null));
    }

    @Test
    void derovEmptyString() {
        assertEquals("", rovar.derov(""));
    }

    @Test
    void derovNon_EmptyStringUpper() {
        assertEquals("ABCDEFGHIJKLMNOPQRSTUVWXYZÅÄÖ",rovar.derov( "ABOBCOCDODEFOFGOGHOHIJOJKOKLOLMOMNONOPOPQOQRORSOSTOTUVOVWOWXOXYZOZÅÄÖ"));
    }

    @Test
    void derovNon_EmptyStringLower() {
        assertEquals("abcdefghijklmnopqrstuvwxyzåäö",rovar.derov("abobcocdodefofgoghohijojkoklolmomnonopopqoqrorsostotuvovwowxoxyzozåäö"));
    }

    @Test
    void derovNon_EmptyStringUpperNumbers() {
        assertEquals("0123456789", rovar.derov("0123456789"));
    }

    @Test
    void derovNon_EmptyStringCharacters() {
        assertEquals(" !”#€%&/(),.", rovar.derov(" !”#€%&/(),."));
    }
}