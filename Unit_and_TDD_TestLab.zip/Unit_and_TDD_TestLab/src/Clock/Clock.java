package Clock;

public class Clock {
    private Time theTime = new Time();
    private Date theDate = new Date();
    private States state = States.displayTime;

    public Clock(){
    }

    public String changeMode(){
        switch(state) {
            case displayTime:
                    state = States.displayDate;
                    return theDate.showDate();
            case displayDate:
                state = States.displayTime;
                return theTime.showTime();
            case changeTime:
                return "Can't change mode while setting time!";
            case changeDate:
                return "Can't change mode while setting date!";
            default:
        }
        return null;
    }

    public String ready(){
        switch(state){
            case displayTime:
                state = States.changeTime;
                return "Ready to accept time";
            case displayDate:
                state = States.changeDate;
                return "Ready to accept date";
            case changeTime:
                return "Set time is already ready!";
            case changeDate:
                return "Set date is already ready!";
            default:
        }

        return null;
    }

    public String set(int p1, int p2, int p3) {
        switch(state){
            case changeTime:
                String str = theTime.timeSet(p1,p2,p3);
                if(!str.startsWith("Invalid")){
                    state = States.displayTime;
                }
                return str;
            case changeDate:
                String str1 = theDate.dateSet(p1,p2,p3);
                if(!str1.startsWith("Invalid")){
                    state = States.displayDate;
                }
                return str1;
            case displayDate:
                return "Set date not valid";
            case displayTime:
                return "Set time not valid";
            default:
        }
        return null;
    }
}