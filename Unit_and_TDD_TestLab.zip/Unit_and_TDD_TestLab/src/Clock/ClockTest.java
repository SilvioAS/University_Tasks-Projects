package Clock;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ClockTest {

    private Clock clock;

    @BeforeEach
    void setUp() {
        clock = new Clock();
    }

    //Valid State Transitions
    //----------------------------------------------------------------------------

    @Test
    void s1_to_s2(){
        assertEquals("2000-01-01", clock.changeMode());
    }

    @Test
    void s2_to_s1(){
        clock.changeMode();
        assertEquals("00:00:00", clock.changeMode());
    }

    @Test
    void s1_to_s3(){
        assertEquals("Ready to accept time", clock.ready());
    }

    @Test
    void s3_to_s1(){
        clock.ready();
        assertEquals("08:54:30", clock.set(8,54,30));
    }

    @Test
    void s2_to_s4(){
        clock.changeMode();
        assertEquals("Ready to accept date", clock.ready());
    }

    @Test
    void s4_to_s2(){
        clock.changeMode();
        clock.ready();
        assertEquals("2017-03-01", clock.set(2017,3,1));
    }

    //Invalid State Transitions
    //----------------------------------------------------------------------------

    @Test
    void IllegalSetTime(){
        assertEquals("Set time not valid", clock.set(0,0,0));
    }

    @Test
    void IllegalSetDate(){
        clock.changeMode();
        assertEquals("Set date not valid", clock.set(0,0,0));
    }

    @Test
    void IllegalReadyTime(){
        clock.ready();
        assertEquals("Set time is already ready!", clock.ready());
    }

    @Test
    void IllegalReadyDate(){
        clock.changeMode();
        clock.ready();
        assertEquals("Set date is already ready!", clock.ready());
    }

    @Test
    void IllegalChangeModeInTime(){
        clock.ready();
        assertEquals("Can't change mode while setting time!", clock.changeMode());
    }

    @Test
    void IllegalChangeModeInDate(){
        clock.changeMode();
        clock.ready();
        assertEquals("Can't change mode while setting date!", clock.changeMode());
    }

    //Border Tests
    //----------------------------------------------------------------------------

    //Values outside borders
    //

    //Time
    @Test
    void testHourUpperInvalid(){
        clock.ready();
        assertEquals("Invalid Hour", clock.set(24,0,0));
    }@Test
    void testHourLowerInvalid(){
        clock.ready();
        assertEquals("Invalid Hour", clock.set(-1,0,0));
    }

    @Test
    void testMinuteUpperInvalid(){
        clock.ready();
        assertEquals("Invalid Minute", clock.set(0,60,0));
    }

    @Test
    void testMinuteLowerInvalid(){
        clock.ready();
        assertEquals("Invalid Minute", clock.set(0,-1,0));
    }

    @Test
    void testSecondsUpperInvalid(){
        clock.ready();
        assertEquals("Invalid Second", clock.set(0,0,60));
    }

    @Test
    void testSecondsLowerInvalid(){
        clock.ready();
        assertEquals("Invalid Second", clock.set(0,0,-1));
    }


    //Date

    @Test
    void testYearUpperInvalid(){
        clock.changeMode();
        clock.ready();
        assertEquals("Invalid Year", clock.set(2101,1,1));

    }

    @Test
    void testYearLowerInvalid(){
        clock.changeMode();
        clock.ready();
        assertEquals("Invalid Year", clock.set(1999,1,1));
    }

    @Test
    void testMonthUpperInvalid(){
        clock.changeMode();
        clock.ready();
        assertEquals("Invalid Month", clock.set(2000,13,1));
    }

    @Test
    void testMonthLowerInvalid(){
        clock.changeMode();
        clock.ready();
        assertEquals("Invalid Month", clock.set(2000,0,1));
    }

    @Test
    void testDayUpperInvalid(){
        clock.changeMode();
        clock.ready();
        assertEquals("Invalid Day", clock.set(2000,1,32));
    }

    @Test
    void testDayLowerInvalid(){
        clock.changeMode();
        clock.ready();
        assertEquals("Invalid Day", clock.set(2000,1,0));
    }

    //Values Inside Border
    @Test
    void testHourUpperValid(){
        clock.ready();
        assertEquals("23:01:01", clock.set(23,1,1));
    }@Test
    void testHourLowerValid(){
        clock.ready();
        assertEquals("00:01:01", clock.set(0,1,1));
    }

    @Test
    void testMinuteUpperValid(){
        clock.ready();
        assertEquals("00:59:00", clock.set(0,59,0));
    }

    @Test
    void testMinuteLowerValid(){
        clock.ready();
        assertEquals("00:00:00", clock.set(0,0,0));
    }

    @Test
    void testSecondsUpperValid(){
        clock.ready();
        assertEquals("00:00:59", clock.set(0,0,59));
    }

    @Test
    void testSecondsLowerValid(){
        clock.ready();
        assertEquals("00:00:00", clock.set(0,0,0));
    }

    @Test
    void testYearUpperValid(){
        clock.changeMode();
        clock.ready();
        assertEquals("2100-01-01", clock.set(2100,1,1));
    }

    @Test
    void testYearLowerValid(){
        clock.changeMode();
        clock.ready();
        assertEquals("2000-01-01", clock.set(2000,1,1));
    }

    @Test
    void testMonthUpperValid(){
        clock.changeMode();
        clock.ready();
        assertEquals("2000-12-01", clock.set(2000,12,1));
    }

    @Test
    void testMonthLowerValid(){
        clock.changeMode();
        clock.ready();
        assertEquals("2000-01-01", clock.set(2000,1,1));
    }

    @Test
    void testDayUpperValid(){
        clock.changeMode();
        clock.ready();
        assertEquals("2000-01-31", clock.set(2000,1,31));
    }

    @Test
    void testDayLowerValid(){
        clock.changeMode();
        clock.ready();
        assertEquals("2000-01-01", clock.set(2000,1,1));
    }
}