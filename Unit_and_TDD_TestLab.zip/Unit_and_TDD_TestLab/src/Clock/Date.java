package Clock;


public class Date {
    private int theYear = 2000;
    private int theMonth = 1;
    private int theDay = 1;

    protected String dateSet(int theYear, int theMonth, int theDay){
        if(theYear > 2100 || theYear < 2000){ return "Invalid Year";}
        if(theMonth > 12 || theMonth < 1){return "Invalid Month";}
        if(theDay > 31 || theDay < 1){return "Invalid Day";}

        this.theYear = theYear;
        this.theMonth = theMonth;
        this.theDay = theDay;
        return showDate();
    }

    protected String showDate(){
        String[] parts = new String[3];
        parts[0] = String.valueOf(theYear);
        parts[1] = String.valueOf(theMonth);
        parts[2] = String.valueOf(theDay);

        if(parts[1].length() == 1){
            parts[1] = "0"+parts[1];
        }
        if (parts[2].length() == 1){
            parts[2] = "0"+parts[2];
        }

        return parts[0] + "-" + parts[1] + "-" + parts[2];
    }
}
