package Clock;

public class Time {
    private int theHour = 0;
    private int theMinute = 0;
    private int theSecond = 0;

    protected String timeSet(int theHour, int theMinute, int theSecond){
        if(theHour > 23 || theHour < 0){return "Invalid Hour";}
        if(theMinute > 59 || theMinute < 0){return "Invalid Minute";}
        if(theSecond > 59 || theSecond < 0){return "Invalid Second";}

        //Glöm inte byta till invalid hour/minute/second
        this.theHour = theHour;
        this.theMinute = theMinute;
        this.theSecond = theSecond;
        return showTime();
    }

    protected String showTime(){
        String[] parts = new String[3];
        parts[0] = String.valueOf(theHour);
        parts[1] = String.valueOf(theMinute);
        parts[2] = String.valueOf(theSecond);

        if(parts[0].length() == 1){
            parts[0] = "0"+parts[0];
        }
        if(parts[1].length() == 1){
            parts[1] = "0"+parts[1];
        }
        if (parts[2].length() == 1){
            parts[2] = "0"+parts[2];
        }

        return parts[0] + ":" + parts[1] + ":" + parts[2];
    }
}
