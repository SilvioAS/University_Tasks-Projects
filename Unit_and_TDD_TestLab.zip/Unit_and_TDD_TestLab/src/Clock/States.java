package Clock;

enum States {
    displayDate,
    changeDate,
    displayTime,
    changeTime
}
