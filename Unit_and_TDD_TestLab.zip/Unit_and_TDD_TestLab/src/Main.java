import com.company.rovar;
public class Main {
    public static void main(String[] args) {
    }
}