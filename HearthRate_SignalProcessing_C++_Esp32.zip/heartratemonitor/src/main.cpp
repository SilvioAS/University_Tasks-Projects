#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 32
#define OLED_RESET -1 
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
#define SCREEN_ADDRESS 0x3C
#define pulseSensorPin 32

// --- Filter: 3rd Order Butterworth Bandpass (0.8Hz - 5Hz) @ 1000Hz Sampling ---
const double TOTAL_GAIN = 1.229415e-06;
const double SOS_A[3][2] = {
  {-1.988452, 0.988531}, {-1.979055, 0.979203}, {-1.994966, 0.994971}
};
const double SOS_B[3][3] = {
  {1.0, 0.0, -1.0}, {1.0, 2.0, 1.0}, {1.0, -2.0, 1.0}
};
double z[3][2] = {{0,0}, {0,0}, {0,0}};

float applyFilter(float x) {
  double out = x * TOTAL_GAIN;
  for (int i = 0; i < 3; i++) {
    double next_out = out * SOS_B[i][0] + z[i][0];
    z[i][0] = out * SOS_B[i][1] - SOS_A[i][0] * next_out + z[i][1];
    z[i][1] = out * SOS_B[i][2] - SOS_A[i][1] * next_out;
    out = next_out;
  }
  return (float)out;
}

volatile int rawSignal = 0;
volatile bool newSample = false;
portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;

int graph[128];
int graphIndex = 0;
long bpm = 0;
unsigned long lastBeatTime = 0;
unsigned long beatIntervals[10];
int beatCount = 0;
bool beatDetected = false;

// Auto-scaling variables for the graph
float signalMax = 1.0; 
float signalMin = -1.0;

void IRAM_ATTR onTimer(){
  portENTER_CRITICAL_ISR(&timerMux);
  rawSignal = analogRead(pulseSensorPin);
  newSample = true;
  portEXIT_CRITICAL_ISR(&timerMux);
}

void setup() {
  Serial.begin(115200);
  pinMode(pulseSensorPin, INPUT);
  if(!display.begin(SSD1306_SWITCHCAPVCC, SCREEN_ADDRESS)) for(;;);
  
  display.clearDisplay();
  display.setTextColor(WHITE);
  display.display();

  hw_timer_t *timer = timerBegin(0, 80, true);
  timerAttachInterrupt(timer, &onTimer, true);
  timerAlarmWrite(timer, 1000, true); // 1ms
  timerAlarmEnable(timer);
}

void loop() {
  if (newSample) {
    int currentRaw;
    portENTER_CRITICAL(&timerMux);
    currentRaw = rawSignal;
    newSample = false;
    portEXIT_CRITICAL(&timerMux);

    float filtered = applyFilter((float)currentRaw);

    // --- 1. Auto-Scaling Graph Logic (Left-to-Right Fill) ---
    if (filtered > signalMax) signalMax = filtered;
    if (filtered < signalMin) signalMin = filtered;

    // Use a smaller decay so the graph doesn't jump too much
    signalMax *= 0.9999;
    signalMin *= 0.9999;

    graph[graphIndex] = map(filtered * 100, signalMin * 100, signalMax * 100, 31, 10);
    graphIndex++;

    // Clear and reset when screen is full
    if (graphIndex >= 128) {
      graphIndex = 0;
      display.clearDisplay();
    }

    // --- 2. Beat Detection (Requirement: Check every 20ms) ---
    static unsigned long lastCheck = 0;
    if (millis() - lastCheck >= 20) {
      lastCheck = millis();

      // Use a portion of the tracked max as threshold
      float thresholdOn = signalMax * 0.75;

      if (filtered > thresholdOn && !beatDetected) {
        beatDetected = true;
        unsigned long now = millis();
        unsigned long duration = now - lastBeatTime;
        
        if (duration > 350) { // Max ~170 BPM
          lastBeatTime = now;
          beatIntervals[beatCount % 10] = duration;
          beatCount++;

          if (beatCount >= 10) {
            unsigned long sum = 0;
            for(int i=0; i<10; i++) sum += beatIntervals[i];
            bpm = 60000 / (sum / 10);
            Serial.print("BPM: ");
            Serial.println(bpm);
          }
        }
      }
      if (filtered < 0) beatDetected = false;
    }

    // --- 3. Display Refresh ---
    static unsigned long lastDisplay = 0;
    if (millis() - lastDisplay > 30) { 
      display.fillRect(0, 0, 128, 10, BLACK); // Clear only top text area
      display.setCursor(0, 0);
      display.print("BPM: ");
      display.print(bpm);

      // Redraw the graph lines
      for (int x = 0; x < graphIndex - 1; x++) {
        display.drawLine(x, graph[x], x + 1, graph[x+1], WHITE);
      }
      display.display();
      lastDisplay = millis();
    }
  }
}